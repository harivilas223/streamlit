from services.standardizer import Standardizer
from services.blocking_service import BlockingService
from services.matcher import compute_score
from services.entity_service import create_entity
from repositories.entity_repository import EntityRepository

MATCH_THRESHOLD = 0.95
POSSIBLE_THRESHOLD = 0.75

entity_repo = EntityRepository()
blocking_service = BlockingService()

class Resolver:
    def __init__(self):
        self.standardizer = Standardizer()

    def resolve(self, record):
        record = self.standardizer.normalize(record)

        candidates = blocking_service.get_candidates(record)

        best_entity = None
        best_score = 0

        for entity_id in candidates:
            entity = entity_repo.get(entity_id)
            if not entity:
                continue

            score = compute_score(record, entity)

            if score > best_score:
                best_score = score
                best_entity = entity

        if best_entity and best_score >= MATCH_THRESHOLD:
            return {
                'decision': 'MATCH',
                'entity_id': best_entity.entity_id,
                'score': best_score
            }

        if best_entity and best_score >= POSSIBLE_THRESHOLD:
            return {
                'decision': 'POSSIBLE_MATCH',
                'entity_id': best_entity.entity_id,
                'score': best_score
            }

        entity = create_entity(record)
        entity_repo.save(entity)

        return {
            'decision': 'NEW_ENTITY',
            'entity_id': entity.entity_id,
            'score': 1.0
        }
