import uuid
from models.entity_profile import EntityProfile

def create_entity(record):
    entity = EntityProfile('E-' + str(uuid.uuid4())[:8])
    entity.records.append(record.record_id)
    entity.names.add(f"{record.first_name} {record.last_name}")
    entity.phones.add(record.phone)
    entity.emails.add(record.email)
    entity.addresses.add(record.address)
    if record.dob:
        entity.dobs.add(record.dob)
    if record.gender:
        entity.genders.add(record.gender)
    return entity
