import re

class Standardizer:
    def normalize(self, record):
        record.first_name = record.first_name.lower().strip()
        record.last_name = record.last_name.lower().strip()
        record.email = record.email.lower().strip()
        record.phone = re.sub(r'\D', '', record.phone)
        if len(record.phone) == 10:
            record.phone = '91' + record.phone
        return record
