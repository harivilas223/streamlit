from rapidfuzz import fuzz

def compute_score(record, entity):
    score = 0
    name = f"{record.first_name} {record.last_name}"

    best = 0
    for n in entity.names:
        best = max(best, fuzz.token_sort_ratio(name, n)/100)

    score += 0.4 * best
    score += 0.3 * int(record.phone in entity.phones)
    score += 0.2 * int(record.email in entity.emails)
    score += 0.1 * int(record.dob in entity.dobs)
    return score
