class BlockingService:
    def __init__(self):
        self.phone_index = {}
        self.email_index = {}

    def get_candidates(self, record):
        candidates = set()
        candidates.update(self.phone_index.get(record.phone, []))
        candidates.update(self.email_index.get(record.email, []))
        return list(candidates)
