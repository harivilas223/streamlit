from fastapi import APIRouter
from models.customer_record import CustomerRecord
from services.resolver import Resolver

router = APIRouter()
resolver = Resolver()

@router.post("/records")
def ingest(record: CustomerRecord):
    return resolver.resolve(record)
