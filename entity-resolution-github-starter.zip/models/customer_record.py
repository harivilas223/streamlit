from pydantic import BaseModel

class CustomerRecord(BaseModel):
    record_id: str
    user_id: str
    first_name: str
    last_name: str
    phone: str
    email: str
    address: str = ""
    dob: str = ""
    gender: str = ""
