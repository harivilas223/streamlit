class EntityProfile:
    def __init__(self, entity_id):
        self.entity_id = entity_id
        self.records = []
        self.names = set()
        self.phones = set()
        self.emails = set()
        self.addresses = set()
        self.dobs = set()
        self.genders = set()
