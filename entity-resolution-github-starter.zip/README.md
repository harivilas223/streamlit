# Entity Resolution POC

Run:

```bash
pip install -r requirements.txt
python app.py
```

POST:

```bash
curl -X POST http://localhost:8000/records \
-H 'Content-Type: application/json' \
-d '{
"record_id":"R1",
"user_id":"U1",
"first_name":"Hari",
"last_name":"Reddy",
"phone":"9876543210",
"email":"hari@gmail.com"
}'
```
